Group 10 Buyme Auction System Project
CS 336 Rutgers University Fall 2022

Collaborators: Hayoon Kim (hk819), Conway Zhou (cz345), Yash Puranik, Yebin Kim

Demo Video: https://youtu.be/UfajPuyQaQI

Credentials:
end users
user: hk345 password: 336BuyMe
user: conway1 password: Torchic
user: yash1 password: Yash
user: yebin1 password: Yebin

customer rep
user: hk345 password: 336BuyMe

admin
user: adminuser123 password: 1234

put your database password in ApplicationDB.java

Contributions:
Hayoon Kim: User login/logout, account creation, landing pages, user schemas, questions handling
Conway Zhou: Alert pages, Alert schemas, Video, Design
Yash Puranik: Bid/Auction schemas, Bid/Auction pages, sales reports
Yebin Kim: Bid/Auction schemas, Bid/Auction pages
